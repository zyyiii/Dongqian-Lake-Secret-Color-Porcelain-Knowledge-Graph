import re
raw = open('dom.html', 'rb').read()
try:
    s = raw.decode('utf-8')
    if 'kg-node' not in s:
        s = raw.decode('utf-16')
except Exception:
    s = raw.decode('utf-16', errors='ignore')
m = re.findall(r'<g transform="([^"]+)"', s)
print('g transforms:', m[:3])
nodes = re.findall(r'class="kg-node" transform="([^"]+)"', s)
print('node count:', len(nodes))
print('first 5 nodes:', nodes[:5])
xs = [float(re.search(r'translate\(([-\d.]+)', t).group(1)) for t in nodes]
ys = [float(re.search(r',([-\d.]+)', t).group(1)) for t in nodes]
print('x range:', min(xs), max(xs))
print('y range:', min(ys), max(ys))
svg = re.search(r'<svg[^>]*viewBox="([^"]+)"', s)
print('viewBox:', svg.group(1) if svg else None)
